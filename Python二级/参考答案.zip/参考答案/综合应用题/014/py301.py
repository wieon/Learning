﻿#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 


fi = open("data301.txt","r")
ss=fi.read()
print(ss.count("<a"))


fi.seek(0)
count = 0
ls = []
flag = 0
for i in ss.split("\n"):
    if ".JPG" in i:
        count += 1

fi.close()
print(count)


fp = open("images.txt","w")

for i in ss.split("\n"):
    if ".JPG" in i:
        start_point = i.find("http://")
        end_point = i.find(".JPG")
        fp.write(i[start_point:end_point+4]+"\n")

fp.close()

