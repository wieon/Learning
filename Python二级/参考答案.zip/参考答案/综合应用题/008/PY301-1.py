﻿# 请在______处使用一行或多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改

fo = open('data.txt', 'r')
lines = fo.read().split('\n')
fo.close()

L = []
for line in lines:
    if "alt=" in line:
        L.append(line)

S = []
for line in L:
    point_start = line.find('alt=') + 5
    point_end = line.find('"', point_start, -1)
    S.append(line[point_start:point_end])

f = open("univ.txt", "w")
for school in S:
    f.write(school)
    f.write('\n')
f.close()
