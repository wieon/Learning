﻿# 请在______处使用一行或多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改

n = 0
k = 0

f = open("univ.txt", "r")
lines = f.read().split('\n')
f.close()

for school in lines:
    if (("大学" in school) or ("学院" in school)) and ("大学生" not in school):
        print(school)
        if "大学" in school:
            n += 1
        elif "学院" in school:
            k += 1

print("包含大学的名称数量是{}".format(n))
print("包含学院的名称数量是{}".format(k))
