#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可修改其他代码

import jieba

fs = open("data301.txt", "r")
lss = fs.readlines()
fs.close()

lens =0
for lr in lss:
    if lr != "\n":
        lens += 1
print("共{}个非空行。".format(lens))

ts = {}
for lr in lss:
    if lr.strip() != "":
        words = lr.strip().split(":")
        ts[words[0]] = ts.get(words[0],[])
        ts[words[0]].append(words[1])

names = ts.keys()
print("共{}个人发言：{}".format(len(ts),",".join(names)))

for r in ts.keys():
    words = []
    for i in ts[r]:
        words += jieba.lcut(i)
    d = {}
    for i in words:
        if len(i) > 1:
            d[i] = d.get(i,0) + 1
    lt = list(d.items())
    lt.sort(key = lambda x:x[1], reverse = True)
    
    print("{}说了{}个词，最多的词是：{}".format(r, len(lt), lt[0][0]))


