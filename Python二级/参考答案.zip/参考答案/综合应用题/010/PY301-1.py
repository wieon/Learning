﻿# 
# 以下代码仅供参考。
# 

import jieba
f=open('data.txt','r')
data=f.read()
f.close()
f=open('clean.txt','w')
s=''
x='，。？、‘’“”；：、 ）\n（！'
for i in data:
    if i not in x:
        s+=i
f.write(s)
f.close()
