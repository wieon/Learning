﻿# 
# 以下代码仅供参考。
# 

import jieba

f2018 = open('data2018.txt', 'r')
line2018 = f2018.read().split('\n')
f2018.close()
f2019 = open('data2019.txt', 'r')
line2019 = f2019.read().split('\n')
f2019.close()

d = {}
for i in line2018:
    word = jieba.lcut(i)
    for j in word:
        if len(j) >= 2:
            d[j] = d.get(j,0) + 1
lt = list(d.items())
lt.sort(key = lambda x:x[1],reverse = True)
ls2018 = []
for i in range(10):
    ls2018.append(lt[i][0])

d = {}
for i in line2019:
    word = jieba.lcut(i)
    for j in word:
        if len(j) >= 2:
            d[j] = d.get(j,0) + 1
lt = list(d.items())
lt.sort(key = lambda x:x[1],reverse = True)
ls2019 = []
for i in range(10):
    ls2019.append(lt[i][0])

lslike = []

for i in ls2018:
    if i in ls2019:
        lslike.append(i)

for i in lslike:
    ls2018.remove(i)
    ls2019.remove(i)

print('共有词语:', end = '')
for i in lslike[:-1]:
    print(i, end = ',')
print(lslike[-1])

print('2019特有:', end = '')
for i in ls2019[:-1]:
    print(i, end = ',')
print(ls2019[-1])

print('2018特有:', end = '')
for i in ls2018[:-1]:
    print(i, end = ',')
print(ls2018[-1])
