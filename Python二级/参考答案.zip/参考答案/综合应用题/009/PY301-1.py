﻿# 
# 以下代码仅供参考。
# 

import jieba

f2018 = open('data2018.txt', 'r')
line2018 = f2018.read().split('\n')
f2018.close()
f2019 = open('data2019.txt', 'r')
line2019 = f2019.read().split('\n')
f2019.close()

d = {}
for i in line2018:
    word = jieba.lcut(i)
    for j in word:
        if len(j) >= 2:
            d[j] = d.get(j,0) + 1
lt = list(d.items())
lt.sort(key = lambda x:x[1],reverse = True)
print('2018:',end='')
for i in range(9):
    print('{}:{}'.format(lt[i][0], lt[i][1]), end = '')
    print(',',end = '')
print('{}:{}'.format(lt[9][0], lt[9][1]))

d = {}
for i in line2019:
    word = jieba.lcut(i)
    for j in word:
        if len(j) >= 2:
            d[j] = d.get(j,0) + 1
lt = list(d.items())
lt.sort(key = lambda x:x[1],reverse = True)
print('2019:',end='')
for i in range(9):
    print('{}:{}'.format(lt[i][0], lt[i][1]), end = '')
    print(',',end = '')
print('{}:{}'.format(lt[9][0], lt[9][1]))
