'''
输入文件 ： cand301.txt
输出文件 ： best301.txt
'''
    
fi=open("cand301.txt","r")
fo=open("best301.txt","w")
for i in fi:
  s=i.strip("\n").split()
  if min(list(map(lambda x:eval(x),s[2:])))>=60:
    fo.write(" ".join(s[:2])+"\n")
fi.close()
fo.close()
