# 请在...处使用多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改


    
fi=open("score301.txt")
L=[]
for f in fi:
  st=f.strip("\n").split()
  grade=sum(list(map(lambda x:eval(x),st[2:])))
  st.append(grade)
  L.append(st)
L.sort(key=lambda x:x[-1],reverse=True)
fo=open("cand301.txt","w")
for s in L[0:10]:
  fo.write(" ".join(s[:-1])+"\n")
fi.close()
fo.close()
