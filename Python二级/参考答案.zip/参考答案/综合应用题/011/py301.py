﻿# 请在......处写多行代码
# 建议不修改其他代码

import jieba

fp = open("红楼梦.txt",encoding='utf-8')
ss=fp.read()
fp.close()

point = "，。：；？"

cnt = 0

for i in ss:
    if i in point:
        cnt += 1

print(cnt)

words = jieba.lcut(ss)

dc = []

for i in words:
    if len(i) >= 2:
        dc.append(i)

dc1 = set(dc)
        
print(len(dc1))

d = {}
for i in dc:
    d[i] = d.get(i,0) + 1

lt = list(d.items())
lt.sort(key=lambda x:x[1], reverse=True)
for x in lt[0:2]:
    print("{},{}".format(x[0],x[1]))
