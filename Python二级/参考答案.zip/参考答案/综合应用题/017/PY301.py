﻿#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以修改其他代码
#

# 问题1：
with open("data301.csv","r") as f:
    lines=f.read().split("\n")
    for i in range(5):
        print(lines[i])

# 问题2：
def total(lst):
    sum=0
    for i in lst:
        sum+=i
    return sum
yslst=[]
zzlst=[]
zylst=[]
for line in lines[1:]:
    lst=line.split(',')
    if lst != [""]:
        yslst.append(eval(lst[1]))
        zzlst.append(eval(lst[2]))
        zylst.append(eval(lst[3]))

print('统计,疑似,重症,治愈')
print('总数,{},{},{}'.format(total(yslst),total(zzlst),total(zylst)))
print('最大值,{},{},{}'.format(max(yslst),max(zzlst),max(zylst)))

# 问题3：
d={}
ls=[]
for line in lines[1:-1]:
    lst=line.split(',')
    d[lst[0]]=eval(lst[1])
    
l = list(d.items())
l.sort(key = lambda x:x[1], reverse = True)

avg = total(yslst)/(len(lines)-2)

for line in l:
    if line[1] > avg:
        ls.append(line[0])
    
print(','.join(ls))

