#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以修改其他代码
#

import jieba
fs = open("data301.txt","r")
lss = fs.read()
fs.close()

for c in "，。？！：":
    print('"{}"的个数为{}个'.format(c,lss.count(c)))

ds = {}
words=jieba.lcut(lss)
for w in words:
    ds[len(w)] = ds.get(len(w),[])
    ds[len(w)].append(w)
for i in range(2,6):
    print('{}字词有{}个'.format(i,len(ds[i])))
    ls = ds[i]
    d = {}
    for j in ls:
        d[j] = d.get(j, 0) + 1
    lt = list(d.items())
    lt.sort(key = lambda x:x[1], reverse = True)
    print(lt[0][0])

    

