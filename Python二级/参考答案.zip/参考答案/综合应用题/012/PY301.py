﻿#
# 在____________上补充代码
# 在……上补充一行或多行代码
#



import jieba

fs = open("八十天环游地球.txt", "r")
lss = fs.readlines()

dels=' "？！：，。'

lens =0
new_list = []
for lr in lss:
    if lr != "\n":
        lens += 1
    new_str = ""
    for i in range(len(lr)):
        if lr[i] in dels:
            pass
        else:
            new_str += lr[i]
    new_list.append(new_str)
            
print("共{}个非空行".format(lens))

alens =0
wlens =0

word_list = []
for lr in lss:
    alens += len(lr)
    words = jieba.lcut(lr)
    for i in words:
        word_list.append(i)

wlens = len(word_list)
    
print("剩余字符数{}, 词语数{}".format(alens, wlens))

fo = open("八十天环游地球-章节.txt","w")
for lr in lss:
    if "章　" in lr:
        fo.write(lr)

fo.close()
