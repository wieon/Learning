﻿# 请在...处使用多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改

import jieba

fi = open('data.txt','r')
f = open('out1.txt','w')

words = []
for line in fi.readlines():
    line = line.strip('\n')
    wordlist = jieba.lcut(line) #每一行都是一个list,并且list里已经分词
    for word in wordlist:
        if len(word)>=3 and (word not in words):
            words.append(word)
for word in words:
    f.write(word+'\n')
fi.close()
f.close()
