﻿# 请在...处使用多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改

import jieba

fi = open('data.txt','r')
fo = open('out2.txt','w')

words = []
for line in fi.readlines():
    line = line.strip('\n')
    wordlist = jieba.lcut(line) #每一行都是一个list,并且list里已经分词
    for word in wordlist:
        if len(word)>=3:
            words.append(word)

d = {}
for word in words:
    d[word] = d.get(word,0) + 1

ls = list(d.items())
ls.sort(key=lambda x:x[1], reverse=True) # 此行可以按照词频由高到低排序

s = ''
for i in ls:
    s = '{}:{}'.format(i[0],i[1])
    fo.write(s+'\n')

fi.close()
fo.close()




