# 以下代码为提示框架
# 请在...处使用一行或多行代码替换
# 请在______处使用一行代码替换
#
# 注意：提示框架代码可以任意修改，以完成程序功能为准

fi = open("earpa001.txt", "r")
fo = open("earpa001_count.txt", "w")
d = {}
for line in fi:
    ls = line.strip("\n").split(",")
    m = ls[2] + "-" + ls[3]
    d[m] = d.get(m,0) + 1
ls = list(d.items())
ls.sort(key=lambda x:x[1], reverse=True) # 该语句用于排序
for i in range(len(ls)):
    fo.write('{},{}\n'.format(ls[i][0], ls[i][1]))
fi.close()
fo.close()
