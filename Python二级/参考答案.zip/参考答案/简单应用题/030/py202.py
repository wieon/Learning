#请在.....处填写多行表达式或语句
#不得修改其他代码

import jieba
fuhao=["，","：","、","。","；","“","”"]       
with open("data_19report.txt","r",encoding="utf-8") as f:
    all_txt=f.read()
    for ch in fuhao:
        all_txt=all_txt.replace(ch,'')
   
    words = jieba.lcut(all_txt)
    for i in words[:-1]:
        print(i,end="/")
    print(words[-1])
        
    d = {}
    for i in words:
        d[i] = d.get(i,0) + 1
    ls = list(d.items())
    ls.sort(key = lambda x : x[1], reverse = True)

    for i in range(5):
        print('{}:{}'.format(ls[i][0],ls[i][1]))
