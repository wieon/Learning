#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以修改其他代码
#

fi = open("data202.txt","r")

lls = fi.read().split(";")


print("一共有{}个学生".format(len(lls)))

students = []
for i in lls:
    tem = i.split(",")
    students.append(tem)

students.sort(key=lambda x:x[2], reverse=True)

max_score = students[0][2]
max_name = []
for i in students:
    if i[2] == max_score:
        max_name.append(i[1])
        
min_score = students[-1][2]
min_name = []
for i in students:
    if i[2] == min_score:
        min_name.append(i[1])
        
print("最高分：{}：{}".format(max_score,",".join(max_name)))
print("最低分：{}：{}".format(min_score,",".join(min_name)))
