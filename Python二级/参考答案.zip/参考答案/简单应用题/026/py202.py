﻿#
# 在……上补充一行或多行代码
#
import jieba

s = input("请输入一个中文字符串，包含逗号和句号：\n")
words = jieba.lcut(s)

d = {}
for i in words:
    if len(i) >= 2:
        d[i] = d.get(i, 0) + 1

lt = list(d.items())

fo = open("result202.txt","w",encoding='utf-8')

for i in lt:
    fo.write("{}:{}".format(i[0],i[1]))

fo.close()
