﻿#
# 在……上补充一行或多行代码
# 可以修改其他代码
#
import jieba
s = input("请输入一段中文文本，句子之间以逗号分隔：")

slst = jieba.lcut(s)
wordstr = ""
num = 0

for word in slst:
   if word not in ['，','。']:
      wordstr = wordstr + word + "/"
      num += 1
print(wordstr)

print("非标点符号的中文词语个数是"+str(num))
