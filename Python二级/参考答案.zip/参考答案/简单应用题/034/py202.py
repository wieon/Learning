#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以修改其他代码
#
import random as r
    
def calpi(c,darts):
    p = 0 # 随机数之和
    # 求随机数之和
    for i in range(darts):
        p += r.randint(0,darts)
    print("{:2}{:12}{:12}".format(c, darts, p))

n = 4
DART = 3
r.seed(1)
for i in range(n):
    c = i + 1
    darts = c * DART
    calpi(c,darts)
