#在____________上补充代码
#不要修改其他代码

import turtle as t
color = ['red','green','blue','orange','pink']
for i in range(5):
    t.penup()
    t.goto(-200+i*70,0)
    t.pendown()
    t.pencolor(color[i])
    t.circle(50, steps = 5)
t.done()

