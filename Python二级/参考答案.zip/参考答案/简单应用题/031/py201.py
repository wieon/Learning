#在____________上补充代码
#不要修改其他代码

import random as r
import turtle as t
def drawSnake(angl):
    t.penup()
    t.goto(0,200)
    t.pendown()
    t.seth(-1*angl)
    for i in range(length):
        t.circle(radius, angl)
        t.circle(-radius, angl)

length, radius = 3, 40
r.seed(1)
color = ['red','blue','purple','black']
for i in range(4):
    t.pencolor(r.choice(color))
    angl = r.randint(30, 180)
    drawSnake(angl)
t.done()
