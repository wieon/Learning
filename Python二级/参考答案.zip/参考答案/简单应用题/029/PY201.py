# 请在______处补充一行代码
# 请不要修改其他代码

import turtle as t
for i in range(4):
    t.forward(200)
    t.left(90)
t.penup()
t.goto(100,0)
t.pendown()
t.color("green","red")
t.pensize(5)
t.begin_fill()
t.circle(100)
t.end_fill()# 补充
t.done()
