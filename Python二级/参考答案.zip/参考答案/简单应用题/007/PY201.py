# 请在______处使用一行或多行代码替换
#
# 注意：请不要修改其他已给出代码

import turtle
turtle.pensize(2)
d = 0
for i in range(1, 6):
    turtle.fd(100)
    d += 360/5
    turtle.seth(d)
