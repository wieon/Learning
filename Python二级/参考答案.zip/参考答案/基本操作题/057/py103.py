#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以任意修改代码
#

s = input("请输入字符串：")
for c in s:
    zimu = "qwertyuiopasdfghjklzxcvbnm"
    if c in zimu:
        pass
    else:
        print("不全是英文小写")
        break
else:
    print("全部是英文小写")
