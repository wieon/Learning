#在____________上补充代码
#不要修改其他代码

ss = input("请输入一个字符串：")
for s in ss:
    if ord('A') <= ord(s) <= ord('z'):
        print(s.upper(),end="")
    else:
        continue


