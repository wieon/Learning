#
# 在____________上补充代码
#


n = input('请输入一个正整数:')
for i in range(1,eval(n)+1):
    print('{:0>2}{}{}'.format(i, " ",">"*(i)))
