#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以修改其他代码
#

fi = open("data202.txt","r")
for line in fi.readlines():
    if line != '\n':
        lls = line.strip("\n").split(";")

print("一共有{}个学生".format(len(lls)))

grade = {}
ls = []
# 构建学生信息列表
for i in lls:
    ls.append(i.split(","))

# 构建学生分数字典
for i in ls:
    grade[i[1]] = i[2]
# 构建学生分数列表并排序（字典无法排序）（列表内为元组）
grade_list = list(grade.items())
grade_list.sort(key=lambda x:x[1], reverse=True)

highest_grade = grade_list[0][1]
lowest_grade = grade_list[-1][1]
highest_grade_student = []
lowest_grade_student = []
for student in grade_list:
    if student[1] == highest_grade:
        highest_grade_student.append(student[0])
    else:
        break
for student in grade_list[::-1]:
    if student[1] == lowest_grade:
        lowest_grade_student.append(student[0])
    else:
        break

print("最高分：{}：{}".format(highest_grade, " ".join(highest_grade_student)))
print("最低分：{}：{}".format(lowest_grade, " ".join(lowest_grade_student)))

fi.close()