# 以下代码为提示框架
# 请在...处使用一行或多行代码替换
# 请在______处使用一行代码替换
#
# 注意：提示框架代码可以任意修改，以完成程序功能为准


data = input()  # 课程名 考分
d = {}  
while data:
    ls = data.split(" ")
    d[ls[0]]=ls[1]
    data = input()
ls = list(d.items())
ls.sort(key=lambda x:x[1], reverse=True)
max_course, max_grade = ls[0]
min_course, min_grade = ls[len(ls)-1]
sum = 0
for i in ls:
    sum += eval(i[1])
average_grade = sum / len(ls)
print("最高分课程是{} {}, 最低分课程是{} {}, 平均分是{:.2f}".format(max_course, max_grade, min_course, min_grade, average_grade))
