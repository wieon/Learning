﻿#
# 在……上补充一行或多行代码
#
import jieba

s = input("请输入一个中文字符串，包含逗号和句号：\n")

# 分词并滤掉标点符号
word = jieba.lcut(s)
word = list(filter(lambda x:x not in ['，','。','、'], word))

# 统计词频
count = {}
for i in word:
    if i in count:
        count[i] += 1
    else:
        count[i] = 1

# print(count)

# 将字符长度大于等于2的词语及词频保存到文件
fo = open("result202.txt","w",encoding='utf-8')
save_word = {k:v for k,v in count.items() if len(k) >= 2}
for i in save_word.keys():
    fo.write("{}：{}\n".format(i, save_word[i]))
fo.close()
