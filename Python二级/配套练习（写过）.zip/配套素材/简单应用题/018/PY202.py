#
# 在......上补充一行或多行代码
# 在____________上补充一行代码
# 可以修改代码
#


f = open('data202.csv','r')

d={}
country=[]
school=[]
for line in f.readlines():
    ls = line.strip('\n').split(",")
    if ls != '':
        country.append(ls[2])
        school.append(ls[1:3])
country = list(set(country))
d = {key: [] for key in country}

"""
# 这样在生成字典时键会共享列表，所有键都指向内存中的同一个列表对象
zeros = [[]]*len(country)
d = dict(zip(country, zeros))
"""

for i in school:
    d[i[1]].append(i[0])
    
for country in d.keys():
    print('{:>4}: {:>4} : {}'.format(country,len(d[country]),' '.join(d[country])))
f.close()