for i in school:
#     # print(i)
#     d[i[1]].append(i[0])
# print(d)