#请在......处填写一行或多行表达式或语句
#可以修改其他代码

sumtime = 0
percls = []
ts = {}
f = open('data202.csv', 'r') 
for line in f.readlines():
   percls = line.strip("\n").split(",")
   sumtime += eval(percls[2])
   ts[percls[0]]=percls[2]

print('the total execute time is', sumtime)

tns = list(ts.items())
tns.sort(key=lambda x: x[1], reverse=True)
for i in range(3):
    print('the top {} percentage time is {}, spent in "{}" operation'.format(i, tns[i][1],tns[i][0]))
f.close()
