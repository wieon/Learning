﻿#
# 在……上补充一行或多行代码
# 可以修改其他代码
#
import jieba
s = input("请输入一段中文文本，句子之间以逗号分隔：")

slst = jieba.lcut(s)

# 滤掉句子中标点符号
# 法一
# wordstr = []
# for word in slst:
#    if word not in ['，','。']:
#      wordstr.append(word)

# 法二
wordstr = list(filter(lambda x: x not in [',','.','，','。'], slst))

# print(wordstr)

print("\\".join(wordstr))
print("非标点符号的中文词语个数是 {}".format(len(wordstr)))
