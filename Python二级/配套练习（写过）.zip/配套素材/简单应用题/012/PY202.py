#请完善如下代码
#在....处填写多行代码，不得修改其他代码
#PY202.py


while True:
    s = input("请输入不带数字的文本:")
    n=0
    for i in s:
        if i.isdigit():
            n+=1
    if n==0:
        break
print(len(s))
