#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以修改其他代码
#

import random as r
def calp(c, darts):
    p = 0
    for i in range(darts):
        p += r.randint(0, darts) 
    print("{:2} {:12} {:12}".format(c, darts, p))

r.seed(1)
for i in range(4):
    calp(i, i*3)



