#请在.....处填写多行表达式或语句
#不得修改其他代码

import jieba
fuhao=["，","：","、","。","；","“","”"]       
ff = open("data202.txt","r",encoding="utf-8")
all_txt=ff.read()
for ch in fuhao:
    all_txt=all_txt.replace(ch,'')
ls = jieba.lcut(all_txt)  

for i in range(len(ls)):
    if i>0:
        print('/',end='')
    print(ls[i], end="")
print()

# 统计词频
dc = {}
for i in ls:
    if i in dc:
        dc[i] += 1
    else:
        dc[i] = 1

# 筛选长度大于1的词
dc = {k:v for k,v in dc.items() if len(k)>1}

lt=list(dc.items())
lt.sort(key=lambda x:x[1],reverse=True)
for x in lt[0:5]:
    print("{}:{}".format(x[0],x[1]))
