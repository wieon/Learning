# 请在______处使用一行或多行代码替换
#
# 注意：请不要修改其他已给出代码

import random
random.seed(100)  # 此处可多行
s = 0  # 
for i in range(3):  # 此处可多行
    s += pow(random.randint(1,10), 3)
print(s)
