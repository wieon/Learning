#在____________上补充代码
#不要修改其他代码

ss = input("请输入一个字符串：")
for s in ss:
    if s.isalpha():
        print(s.upper(),end="")
    else:
        continue


