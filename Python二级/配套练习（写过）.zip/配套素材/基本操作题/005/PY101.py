# 请在...处使用一行或多行代码替换
# 请在______处使用一行代码替换
#
# 注意：请不要修改其他已给出代码

import random
brandlist = ['华为','苹果','诺基亚','OPPO','小米']
random.seed(0)
n = random.randint(0,len(brandlist))
name = brandlist[n]
print(name)

# 法二
# import random
# brandlist = ['华为','苹果','诺基亚','OPPO','小米']
# random.seed(0)
# name = random.choice(brandlist)
# print(name)