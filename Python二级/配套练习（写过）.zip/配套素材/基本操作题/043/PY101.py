#
# 编写代码替换横线
#

a = input("请输入填充符号：")
s = "PYTHON"
print("{0:{1:s}^30}".format(s,a))
