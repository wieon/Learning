#请在_______上填写一行表达式或语句
#可以修改其他代码


def allFactor(n):
    if n <=1: return [n]
    if n <=3: return [1,n]
    i=1
    rlist = []
    while i <= n:
        if n % i == 0:
            rlist.append(i)
        i += 1
    return rlist

try:
    n=eval(input("请输入一个正整数:"))
    print("整数{}的因子是:{}".format(n,allFactor(n)))
except:
    print("输入错误!")



