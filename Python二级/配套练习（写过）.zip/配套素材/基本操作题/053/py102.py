#在____________上补充代码
#不要修改其他代码

def vfun(x,b):
    for i in b:
        x += eval(i)
    return x
lc = input().split(",")
print(vfun(10,lc))


