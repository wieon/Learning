sinfo=input()
s = sinfo.split(',')
print("姓名,年龄")
for strname in s:
    sname=strname[:-2]
    sage=strname[-2:]
    print("{},{}".format(sname,sage))


