#在 _____上补充一行代码
#不要修改其他代码

import random
random.seed(20)
sum=0
for i in range(10):
    n = random.randint(1,21)
    sum+=n
    print("第{}个数：{}".format(i,n))
print("10个随机数的平均数是:{}".format(round(sum/10,1)))

