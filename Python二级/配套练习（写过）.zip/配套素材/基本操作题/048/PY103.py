# 请在......处完善代码，可以修改其他代码

import random as r
r.seed(1)
s=input("请输入三个整数 n,m,k：")
slist=s.split(",")
n,m,k = eval(s)
for i in range(0, n):
    print(r.randint(k, m+1))



