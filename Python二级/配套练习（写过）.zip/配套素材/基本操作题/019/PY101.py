#请完善如下代码
s = input()
print("{0:=>25,}".format(eval(s)))
