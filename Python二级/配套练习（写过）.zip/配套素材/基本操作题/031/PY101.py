#
# 在____________上补充代码
#

s = input("请输入一个正整数: ")
cs = 0
for c in s:
    cs += eval(c)
print('{0:=^25}'.format(cs))



