#在 ____________上补充一行代码
#不要修改其他代码


ls = eval(input())
print("输入是：{},平均数是：{}".format(ls, sum(ls)/len(ls)))



