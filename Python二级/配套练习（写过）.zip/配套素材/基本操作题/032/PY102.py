#
# 在____________上补充代码
#


s = input("请输入中文和字母的组合: ")
count = 0
for c in s:
    if ord(c)<65 or ord(c)>122 or 90<ord(c)<97:
        count += 1
print(count)
