# 请在...处使用多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改

f = open("score301.txt", "r")
fo = open("cand301.txt", "w", encoding="utf-8")

d = {}
L = []         
for line in f.readlines():
    line = line.strip("\n").split()
    sum = 0
    for i in range(2, 12):
        sum += eval(line[i])
    d[line[1]] = sum
    L.append(line)
ls = list(d.items())
ls.sort(key=lambda x:x[-1],reverse=True)

for i in ls[:10]:
    for j in range(len(L)):
        if i[0] == L[j][1]:
            fo.write(" ".join(L[j])+"\n")

f.close()
fo.close()


    
