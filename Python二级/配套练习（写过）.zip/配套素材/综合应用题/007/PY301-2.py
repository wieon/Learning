'''
输入文件 ： cand301.txt
输出文件 ： best301.txt
'''

f = open("cand301.txt", "r", encoding="utf-8")
fo = open("base301.txt", "w", encoding="utf-8")

L = []
for line in f.readlines():
    line = line.strip("\n").split()
    if min(list(map(lambda x:eval(x), line[2:]))) >=60:
        L.append(line[:2])
print(L)
for i in L:
    fo.write(" ".join(i)+"\n")

f.close()
fo.close()
