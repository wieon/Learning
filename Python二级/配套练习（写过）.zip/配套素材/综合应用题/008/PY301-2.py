﻿# 请在______处使用一行或多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改


f = open("univ.txt", "r")

n = 0
m = 0
L = []
ls = f.readlines()
f.close()
for line in ls:
    line = line.strip("\n")
    if "大学" in line and "大学生" not in line:
        L.append(line)
        n += 1
    if "学院" in line and "大学" not in line:
        L.append(line)
        m += 1

for i in L:
    print(i)
print("包含大学的名称数量是{}".format(n))
print("包含学院的名称数量是{}".format(m))
