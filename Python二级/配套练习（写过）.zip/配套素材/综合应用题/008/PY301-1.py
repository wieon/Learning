﻿# 请在______处使用一行或多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改

fi = open("data.txt", "r")
f = open("univ.txt", "w")

# 大学名称在<alt>标签里
L = []
ls = fi.read().split("\n")
for line in ls:
    if "alt=" in line:
        L.append(line)

S = []
for i in L:
    start_point = i.find("alt=")+5
    end_point = i.find('"', start_point, -1)
    S.append(i[start_point:end_point])

for j in S:
    f.write(j+"\n")


fi.close()
f.close()
