﻿#
# 在____________上补充代码
# 在……上补充一行或多行代码
#



import jieba

fs = open("八十天环游地球.txt", "r")
lss = fs.readlines()
____________

dels=' "？！：，。'

lens =0
for lr in lss:
    ……
print("共{}个非空行".format(lens))

alens =0
wlens =0
for lr in lss:
    ……
    
        
print("剩余字符数{}, 词语数{}".format(alens, wlens))

fo = ____________
for lr in lss:
    
    …… 
fo.close()
