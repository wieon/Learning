﻿#
# 在____________上补充代码
# 在……上补充一行或多行代码
#


fi = open("data301.txt","r")
dc = {}
name = ''
count = 0
flag = 1
for line in fi:
    if '"name":' in line:
        name = line.____________[1].strip(' ,"\n')
        flag = 1
    elif '"value":' in line and flag == 1:
        dx = int(line.split(':')[1].strip(' \n'))
        dc[name] = dx
        flag = 0
        ____________
fi.close()
print("一共有{}个国家".format(count))


……
print("确诊人数最多的国家是{}，人数是{}".format(____________))

lw = 0
lz = 0
……
print("确诊人数超过1W的国家有{}个".format(lw))
print("确诊人数为0的国家有{}个".format(lz))
