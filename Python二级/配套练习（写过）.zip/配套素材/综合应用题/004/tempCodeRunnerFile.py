for i in range(len(ls)):
#     fo.write("{}:{}".format(ls[i][0], ls[i][1]))