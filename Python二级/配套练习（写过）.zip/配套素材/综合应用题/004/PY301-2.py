# 以下代码为提示框架
# 请在...处使用一行或多行代码替换
#
# 注意：提示框架代码可以任意修改，以完成程序功能为准

f = open("命运.txt", "r")
d = {}
punc_marks = "，。、？！《》（）：；“”——\"……:\n"
for i in f.read():
    if i not in punc_marks:
        if i in d:
            d[i] += 1
        else:
            d[i] = 1
ls = list(d.items())
ls.sort(key=lambda x:x[1], reverse=True)
for i in range(10):
    print(ls[i][0], end="")

f.close()
