#
# 在……上补充一行或多行代码
# 可修改其他代码
#

stop_word=['我们','同时','之后','更好','这些','进行']

#第一问：读文件，统计文件中的字符数
f1=open('data301.txt','rt')

……


#第二问：统计词频，输出长度大于1的词的个数，排除特殊词

import jieba
……

for word in txt_wordslist:
 
    ……
        
print("长度大于1且不相同的词的个数是{}。".format(len(word_count.items())))


……
wordlist.sort(key=lambda x:x[1],reverse=True)
……
print("词频最大的词是：{}".format(topword))

#第三问：将长度大于1并且词频最大的词所在的句子，排除特殊词

sentence_list=txt.split('。')
……
for sentence in sentence_list:
    if topword in sentence:
       ……




