﻿#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 


fi = open("data301.txt","r")
ss=fi.read()
print(ss.count("<a"))


fi.seek(0)
count = 0
ls = []
flag = 0
# print(ss.count(".JPG"))
s = ss.split("\n")
for i in s:
    if ".JPG" in i:
        ls.append(i)
img = []
for i in ls:
    start_point = i.find("http://")
    end_point = i.find('"', start_point, -1)
    img.append(i[start_point:end_point])
count = len(img)
fi.close()
print(count)


fp = open("images.txt","w")
for i in img:
    fp.write(i+"\n")
fp.close()

