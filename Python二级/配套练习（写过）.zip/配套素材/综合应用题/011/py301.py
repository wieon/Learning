﻿# 请在......处写多行代码
# 建议不修改其他代码

import jieba

fp = open("红楼梦.txt",encoding='utf-8')
ss=fp.read()
fp.close()
... ...
print(cnt)

... ...
print(len(dc))

... ...
lt.sort(key=lambda x:x[1], reverse=True)
for x in lt[0:2]:
    ... ...
