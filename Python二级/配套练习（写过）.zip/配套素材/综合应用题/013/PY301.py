﻿#
# 在……上补充一行或多行代码
# 可修改其他代码

#第一问：统计素材文件中学生人数


f1=open('data301.txt','rt')
stu_lst=……
……


#第二问：计算所有学生的平均分

stu_dic={}
for stu_str in stu_lst:
    if '\n' in stu_str:
        stu_str=stu_str.replace('\n','')
    stu=stu_str.split(':')
    name=stu[0]
    score=stu[1].split(',')[1]
    
    ……

avg=sum([int(score) for score in stu_dic.values()])/len(stu_dic)

……

#第三问：输出学生分数信息到result文件中

name_score=list(stu_dic.items())
……


name_score_lst=[item[0]+","+item[1]+"\n" for item in name_score]
f2=open('result301.txt','wt')
……
f2.close()
