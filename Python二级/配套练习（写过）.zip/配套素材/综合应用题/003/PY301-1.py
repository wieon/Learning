# 以下代码为提示框架
# 请在...处使用一行或多行代码替换
# 请在______处使用一行代码替换
#
# 注意：提示框架代码可以任意修改，以完成程序功能为准

# 读入数据，构建星座信息二维列表
f = open("PY301-SunSign.csv", "r")
ls = []
for line in f.readlines():
      line = line.strip("\n").split(",")
      ls.append(line)

# 用户查询
n = input("请输入星座中文名称：")
for i in ls:
      if n == i[1]:
            print("{}的生日位于{}-{}之间".format(n, i[2], i[3]))
f.close()


