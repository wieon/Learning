# 以下代码为提示框架
# 请在...处使用一行或多行代码替换
#
# 注意：提示框架代码可以任意修改，以完成程序功能为准


# 读入数据，构建星座信息二维列表
f = open("PY301-SunSign.csv", "r")
ls = []
for line in f.readlines():
      line = line.strip("\n").split(",")
      ls.append(line)

# 用户查询
n = input("请输入星座序号：")
n = n.split(" ")
for j in n:
      for i in ls:
            if j == i[0] and eval(j) <= 11:
                  print("{}({})的生日是{}月{}日至{}月{}日之间".format(i[1], i[4], j, i[2].replace(j,""), str(eval(j)+1), i[3].replace(str(eval(j)+1),"")))
            if j == i[0] and eval(j) == 12:
                  print("{}({})的生日是{}月{}日至{}月{}日之间".format(i[1], i[4], j, i[2].replace(j,""), 1, 19))
f.close()

      
