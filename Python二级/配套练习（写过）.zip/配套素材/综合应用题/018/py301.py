#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可以修改其他代码
#

import jieba
fs = open("data301.txt","r")
lss = fs.read()
fs.close()

for c in "，。？！：":
    print('"{}"的个数为{}个'.format(____________))

ds = {}
words=jieba.lcut(lss)
for w in words:
    ……
for i in range(2,6):
    print('{}字词有{}个'.format(____________))


……
    
