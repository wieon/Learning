# 以下代码为提示框架
# 请在...处使用一行或多行代码替换
# 请在______处使用一行代码替换
#
# 注意：提示框架代码可以任意修改，以完成程序功能为准

f = open("sensor.txt","r",encoding="utf-8")
result = []
for line in f.readlines():
    ls = line.strip("\n").split(',')
    if ls[1] == " earpa001":
        result.append(ls)
f.close()
fo = open("earpa001.txt","w",encoding="utf-8")
for i in result:
    fo.write('{},{},{},{}\n'.format(i[0],i[1],i[2],i[3]))
fo.close()


