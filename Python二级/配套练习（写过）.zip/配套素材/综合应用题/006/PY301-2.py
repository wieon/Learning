﻿# 请在...处使用多行代码替换
#
# 注意：其他已给出代码仅作为提示，可以修改

import jieba
f = open('data.txt','r')
fo = open('out2.txt','w')
d = {}
for line in f.readlines():
    line = line.strip("\n")
    wordlist = jieba.lcut(line)
    for word in wordlist:
        if len(word) >= 3 and word not in d:
            d[word] = 1
        if len(word) >= 3 and word in d:
            d[word] += 1

ls = list(d.items())
ls.sort(key=lambda x:x[1], reverse=True)
lls = []
for i in ls:
    lls.append("{}:{}".format(i[0],i[1]))
for i in lls:
    fo.writelines(i+"\n")

f.close()
fo.close()
