#
# 在____________上补充代码
# 在……上补充一行或多行代码
# 可修改其他代码

import jieba

fs = open("data301.txt", "r")
lss = fs.readlines()
fs.close()

lens =0
for lr in lss:
    ……
print("共{}个非空行。".format(lens))

ts = {}
for lr in lss:
    ……

names = ts.keys()
print("共{}个人发言：{}".format(len(ts),",".join(names)))

for r in ts.keys():
    
    ……

    
    print("{}说了{}个词，最多的词是：{}".format(____________))
